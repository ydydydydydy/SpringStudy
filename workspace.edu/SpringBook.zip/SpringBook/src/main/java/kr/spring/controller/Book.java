package kr.spring.controller;

public interface Book {


}
