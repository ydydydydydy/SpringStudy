git add .
git commit -m "studyed"
git push origin master
