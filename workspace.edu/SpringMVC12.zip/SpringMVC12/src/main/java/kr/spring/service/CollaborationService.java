package kr.spring.service;

import java.util.List;

import kr.spring.entity.tb_company;
import kr.spring.entity.tb_request;

public interface CollaborationService {
   
   public void request(tb_request vo);

   
}