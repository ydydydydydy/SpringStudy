package kr.spring.entity;

public enum Role {
	ADMIN , MEMBER;
}
